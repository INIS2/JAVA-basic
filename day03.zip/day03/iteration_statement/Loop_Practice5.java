// for 반복 연습 2
// 272p
package iteration_statement;

public class Loop_Practice5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			System.out.println("★");
		}// for
		System.out.println();
		
		for (int i = 0; i < 5; i++) {
			System.out.println("커피");
		}

		for (int i = 0; i < 3; i++) {
			System.out.println("커피우유");
		}

		for (int i = 0; i < 3; i++) {
			System.out.println((i+1) + ": 짱");
		}
	}

}
