// for 반복
// 272p
package iteration_statement;

public class Loop_Practice4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 3.; i++) {
			System.out.println("★");
		}
	}

}
